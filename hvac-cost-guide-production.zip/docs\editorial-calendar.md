# HVAC Cost Guide &mdash; Prioritized Editorial Calendar & Production Roadmap

> **Target Country:** United States | **Language:** English  
> **Target Audience:** US Homeowners & Residential HVAC Consumers  
> **Production Architecture:** 10 First-Priority Pages &rarr; 20 Next Expansion Pages &rarr; Future Long-Tail Opportunities

---

## 1. Editorial Pipeline Structure

This editorial roadmap outlines the sequencing of content optimizations and new page builds to establish authoritative topical depth while avoiding keyword cannibalization or low-value thin pages.

```mermaid
graph TD
    A[Editorial Production Pipeline] --> B[Batch 1: First 10 Priority Money Pages]
    A --> C[Batch 2: Next 20 High-Intent Expansion Pages]
    A --> D[Batch 3: Future Topic Opportunities]
    
    B --> B1[Enhance existing core guides with exact query tables & Schema]
    C --> C1[Target component repairs, brand comparisons, & emerging tech]
    D --> D1[Geothermal, municipal incentive tracking, & multi-zone commercial]
```

---

## 2. Batch 1: First 10 Priority Pages (Immediate Optimization)

These 10 pages represent the highest commercial intent, traffic potential, and AdSense RPM.

### Page 1: `/hvac-replacement-cost/`
- **Primary Keyword:** `cost to replace hvac system 2000 sq ft`
- **Secondary Keywords:** `cost to replace furnace and ac at same time`, `hvac replacement cost 3 ton unit`, `average cost to replace hvac unit and ductwork`
- **Intent:** Commercial Investigation
- **Priority:** **HIGH**
- **Content Type:** Comprehensive Cost Guide & Sizing Matrix
- **Suggested Title:** `2026 HVAC Replacement Cost | Full System Pricing Guide`
- **Internal Links:** [`/ac-replacement-cost/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/ac-replacement-cost/index.html), [`/furnace-replacement-cost/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/furnace-replacement-cost/index.html), [`/ductwork-replacement-cost/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/ductwork-replacement-cost/index.html), [`/hvac-cost-calculator/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/hvac-cost-calculator/index.html)
- **Required Data:** Cost by home size (1,000&ndash;3,500 sq ft), labor hours (12&ndash;24 hrs), permit costs ($150&ndash;$450).
- **Required Sources:** EIA Residential Energy Consumption Survey, ACCA Quality Installation Guidelines.
- **Tool / Calculator:** Embedded Dynamic HVAC Replacement Cost Calculator.

### Page 2: `/ac-replacement-cost/`
- **Primary Keyword:** `average cost of 3 ton ac unit installed`
- **Secondary Keywords:** `cost to replace 4 ton ac unit`, `central ac replacement cost 1800 sq ft`, `labor cost to replace central ac unit`
- **Intent:** Commercial Investigation
- **Priority:** **HIGH**
- **Content Type:** Equipment Tonnage & Efficiency Guide
- **Suggested Title:** `2026 AC Replacement Cost | Installed Central Air Pricing`
- **Internal Links:** [`/what-size-ac-do-i-need/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/what-size-ac-do-i-need/index.html), [`/ac-repair-cost/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/ac-repair-cost/index.html), [`/ac-compressor-replacement-cost/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/ac-compressor-replacement-cost/index.html), [`/ac-repair-vs-replacement/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/ac-repair-vs-replacement/index.html)
- **Required Data:** Costs across 1.5 to 5.0 ton ratings, SEER2 baseline rules (North vs. South).
- **Required Sources:** DOE SEER2 Standards, AHRI Directory of Certified Products.
- **Tool / Calculator:** AC Tonnage Cost Estimator.

### Page 3: `/ac-repair-cost/`
- **Primary Keyword:** `ac capacitor replacement cost`
- **Secondary Keywords:** `cost to fix freon leak in home ac`, `cost to add 3 lbs of r410a refrigerant`, `ac fan motor replacement cost`
- **Intent:** Commercial / Transactional
- **Priority:** **HIGH**
- **Content Type:** Diagnostic Repair Pricing Directory
- **Suggested Title:** `AC Repair Cost Guide (2026) | Most Common AC Fixes & Prices`
- **Internal Links:** [`/ac-repair-vs-replacement/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/ac-repair-vs-replacement/index.html), [`/ac-compressor-replacement-cost/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/ac-compressor-replacement-cost/index.html), [`/hvac-maintenance-cost/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/hvac-maintenance-cost/index.html)
- **Required Data:** Part cost vs. technician labor cost for 12 major repairs; R-410A per-pound pricing ($60&ndash;$150/lb).
- **Required Sources:** EPA Section 608 Refrigerant Recycling Regulations, contractor flat-rate labor books.
- **Tool / Calculator:** Component Repair Cost Diagnostic Widget.

### Page 4: `/furnace-replacement-cost/`
- **Primary Keyword:** `cost to replace gas furnace 2000 sq ft`
- **Secondary Keywords:** `high efficiency 96 afue furnace replacement cost`, `cost to convert oil furnace to gas`, `cost to replace 80 afue with 95 afue furnace`
- **Intent:** Commercial Investigation
- **Priority:** **HIGH**
- **Content Type:** Heating Fuel & AFUE Efficiency Guide
- **Suggested Title:** `2026 Furnace Replacement Cost | Gas, Electric & Oil Heating`
- **Internal Links:** [`/furnace-repair-cost/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/furnace-repair-cost/index.html), [`/furnace-vs-heat-pump/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/furnace-vs-heat-pump/index.html), [`/how-long-does-a-furnace-last/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/how-long-does-a-furnace-last/index.html)
- **Required Data:** Gas vs. electric vs. oil pricing; 80% vs. 96% AFUE fuel savings; PVC exhaust venting costs ($400&ndash;$900).
- **Required Sources:** AGA Gas Facts, Energy Star Annual Fuel Utilization Efficiency standards.
- **Tool / Calculator:** AFUE Fuel Cost Savings Calculator.

### Page 5: `/ac-repair-vs-replacement/`
- **Primary Keyword:** `5000 dollar rule hvac repair vs replace calculator`
- **Secondary Keywords:** `when is an ac unit beyond repair`, `signs compressor is failing on central ac`, `ac repair vs replacement cost`
- **Intent:** Informational / Commercial Decision
- **Priority:** **HIGH**
- **Content Type:** Decision Rule & Interactive Decision Tree
- **Suggested Title:** `AC Repair vs. Replace Guide (2026) | The $5,000 Rule & Calculator`
- **Internal Links:** [`/ac-repair-cost/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/ac-repair-cost/index.html), [`/ac-replacement-cost/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/ac-replacement-cost/index.html), [`/how-long-does-an-ac-last/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/how-long-does-an-ac-last/index.html)
- **Required Data:** Cumulative breakdown curves; 8-year vs. 12-year vs. 15-year risk thresholds.
- **Required Sources:** Consumer Reports HVAC Reliability Reports, ACCA Service Evaluation Standards.
- **Tool / Calculator:** Embedded "$5,000 Rule" JavaScript Tool.

### Page 6: `/ductwork-replacement-cost/`
- **Primary Keyword:** `cost to replace ductwork in attic 2000 sq ft`
- **Secondary Keywords:** `cost per linear foot to replace ductwork`, `cost to seal and insulate ductwork`, `cost to install ductwork in a house with no ducts`
- **Intent:** Commercial Investigation
- **Priority:** **HIGH**
- **Content Type:** Retrofit & Airflow Distribution Guide
- **Suggested Title:** `Ductwork Replacement Cost (2026) | Attic, Crawl Space & Installation`
- **Internal Links:** [`/hvac-replacement-cost/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/hvac-replacement-cost/index.html), [`/central-ac-installation-cost/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/central-ac-installation-cost/index.html), [`/mini-split-installation-cost/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/mini-split-installation-cost/index.html)
- **Required Data:** Cost per linear foot ($25&ndash;$55/ft), flex duct vs. sheet metal, R-8 attic insulation code compliance.
- **Required Sources:** SMACNA Duct Construction Standards, Energy Star Duct Sealing reports.
- **Tool / Calculator:** Duct Linear Footage Estimator.

### Page 7: `/mini-split-installation-cost/`
- **Primary Keyword:** `single zone mini split installation cost`
- **Secondary Keywords:** `2 zone mini split installation cost`, `3 zone ductless mini split cost installed`, `cost to install mini split in garage`
- **Intent:** Commercial Investigation
- **Priority:** **HIGH**
- **Content Type:** Multi-Zone Ductless Buyer's Guide
- **Suggested Title:** `Mini Split Installation Cost (2026) | Ductless Cost by Zones`
- **Internal Links:** [`/heat-pump-cost/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/heat-pump-cost/index.html), [`/central-ac-installation-cost/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/central-ac-installation-cost/index.html), [`/hvac-zoning-system-cost/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/hvac-zoning-system-cost/index.html)
- **Required Data:** Zone tier pricing (1 to 5 zones), brand hardware pricing (Mitsubishi, Daikin, MrCool), 240V subpanel wiring costs.
- **Required Sources:** NEEP Cold Climate Air Source Heat Pump specifications, NEC Article 440.
- **Tool / Calculator:** Multi-Zone Ductless Sizing & Cost Calculator.

### Page 8: `/furnace-vs-heat-pump/`
- **Primary Keyword:** `cost to switch from gas furnace to heat pump`
- **Secondary Keywords:** `dual fuel heat pump system cost`, `heat pump savings calculator vs gas heat`, `electric heat pump vs gas heat operating cost`
- **Intent:** Commercial Investigation / Educational
- **Priority:** **HIGH**
- **Content Type:** Technology Comparison & Decarbonization Guide
- **Suggested Title:** `Furnace vs. Heat Pump (2026) | Cost, Efficiency & Conversion Guide`
- **Internal Links:** [`/heat-pump-cost/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/heat-pump-cost/index.html), [`/furnace-replacement-cost/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/furnace-replacement-cost/index.html), [`/heat-pump-installation-cost/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/heat-pump-installation-cost/index.html)
- **Required Data:** Coefficient of Performance (COP) at 47&deg;F vs. 17&deg;F vs. 5&deg;F; IRA Section 25C $2,000 tax credit qualification; 200A electrical panel upgrade costs ($1,500&ndash;$3,000).
- **Required Sources:** Rewiring America IRA Guide, DOE Building Technologies Office.
- **Tool / Calculator:** Gas vs. Heat Pump Utility Bill Comparison Calculator.

### Page 9: `/what-size-ac-do-i-need/`
- **Primary Keyword:** `ac tonnage calculator by square footage`
- **Secondary Keywords:** `how many tons of ac for 2000 sq ft house`, `how many tons of ac for 1500 sq ft house`, `manual j residential load calculation basics`
- **Intent:** Informational Sizing Guide
- **Priority:** **HIGH**
- **Content Type:** Engineering Sizing Reference
- **Suggested Title:** `What Size AC Do I Need? | AC Tonnage & Sizing Guide (2026)`
- **Internal Links:** [`/ac-replacement-cost/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/ac-replacement-cost/index.html), [`/hvac-replacement-cost/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/hvac-replacement-cost/index.html), [`/hvac-cost-calculator/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/hvac-cost-calculator/index.html)
- **Required Data:** Square footage to tonnage matrix; climate zone multipliers (Zone 1 Hot to Zone 5 Cold); short-cycling humidity risks.
- **Required Sources:** ACCA Manual J (Residential Load Calculation), Energy Star Sizing Guides.
- **Tool / Calculator:** Interactive AC Tonnage Estimator.

### Page 10: `/hvac-cost-calculator/`
- **Primary Keyword:** `hvac replacement cost calculator by square footage`
- **Secondary Keywords:** `full hvac replacement cost estimator`, `how to calculate hvac labor cost`, `hvac cost estimator online`
- **Intent:** Commercial Tool / Interactive Application
- **Priority:** **HIGH**
- **Content Type:** Flagship Interactive Tool Page
- **Suggested Title:** `2026 HVAC Cost Calculator | Estimate Replacement & Installation`
- **Internal Links:** All 10 state guides under [`/hvac-by-state/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/hvac-by-state/index.html), [`/methodology/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/methodology/index.html), [`/hvac-replacement-cost/`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/hvac-replacement-cost/index.html)
- **Required Data:** Parametric sizing algorithms, BLS regional labor index tiers (0.88x to 1.35x), add-on costs.
- **Required Sources:** U.S. Bureau of Labor Statistics Occupational Wage Reports, RSMeans.
- **Tool / Calculator:** Standalone, full-width HVAC Cost Calculator with dynamic results bar and disclaimer.

---

## 3. Batch 2: Next 20 High-Intent Expansion Pages

| # | Proposed URL | Primary Keyword | Search Intent | Priority | Content Focus |
| :- | :--- | :--- | :--- | :--- | :--- |
| **11** | `/ac-not-cooling/` | `ac blowing warm air troubleshooting and repair cost` | Informational / Commercial | HIGH | Diagnostic symptom guide: capacitor, refrigerant, thermostat, dirty coil. |
| **12** | `/refrigerant-leak-repair-cost/` | `cost to fix freon leak in home ac` | Commercial / Transactional | HIGH | Per-pound R-410A vs R-22 recharge costs, nitrogen leak testing fees. |
| **13** | `/blower-motor-replacement-cost/` | `furnace blower motor replacement cost` | Commercial / Transactional | HIGH | PSC vs ECM variable speed motors, OEM vs universal replacement pricing. |
| **14** | `/seer2-ratings-guide/` | `what is a good seer2 rating` | Informational | MEDIUM | 2023 DOE regional standards, SEER vs SEER2 comparison, payback curves. |
| **15** | `/hvac-financing-options/` | `how to finance a new hvac system` | Commercial Investigation | HIGH | Contractor financing (0% APR offers), HELOC, PACE loans, FHA Title I. |
| **16** | `/heat-pump-tax-credits-2026/` | `inflation reduction act heat pump tax credit 2026` | Commercial / Informational | HIGH | Section 25C $2,000 credit, HOMES Act rebates, CEE Tier 1/2 requirements. |
| **17** | `/best-hvac-brands-cost/` | `carrier vs trane vs lennox cost` | Commercial Investigation | HIGH | Tier 1 (Carrier/Trane) vs Tier 2 (Goodman/Rheem) price & reliability comparison. |
| **18** | `/quietest-central-ac-units/` | `quietest central air conditioner decibel ratings` | Commercial Investigation | MEDIUM | Variable-speed inverter compressor sound ratings (55 dBA vs 72 dBA). |
| **19** | `/mrcool-diy-mini-split-cost/` | `diy mini split installation cost vs professional` | Commercial Investigation | HIGH | MrCool 4th Gen pricing, vacuum pump requirements, warranty coverage. |
| **20** | `/thermostat-wiring-c-wire-guide/` | `cost to run a c wire for smart thermostat` | Informational / Commercial | MEDIUM | 24V common wire installation, add-a-wire adapters, electrician fees ($150-$300). |
| **21** | `/hvac-permit-cost-requirements/` | `do you need a permit to replace hvac unit` | Informational | MEDIUM | Municipal code requirements, unpermitted install home sale consequences. |
| **22** | `/air-duct-cleaning-worth-it/` | `air duct cleaning cost 2000 sq ft house` | Commercial Investigation | MEDIUM | EPA stance on duct cleaning, NADCA standards, scam avoidance checklist. |
| **23** | `/hvac-surge-protector-cost/` | `whole house hvac surge protector installation cost` | Commercial Investigation | MEDIUM | Inverter board lightning and brownout protection, equipment warranties. |
| **24** | `/electric-vs-gas-heat-cost/` | `is gas or electric heating cheaper` | Informational / Commercial | HIGH | Therm vs kWh cost calculations, regional utility rates, COP heat pump parity. |
| **25** | `/how-to-hire-hvac-contractor/` | `questions to ask hvac contractor before replacing` | Commercial Investigation | HIGH | 10-point contractor vetting checklist, Manual J verification, bid comparison. |
| **26** | `/hvac-zoning-vs-mini-splits/` | `hvac zoning system vs ductless mini splits cost` | Commercial Investigation | MEDIUM | Motorized dampers vs multi-head ductless for uneven two-story home temps. |
| **27** | `/cost-to-move-outdoor-ac-unit/` | `cost to relocate outside ac condenser unit` | Commercial / Transactional | MEDIUM | Line set extension, electrical disconnect relocation, pad pouring ($1,000-$2,500). |
| **28** | `/furnace-short-cycling-cost/` | `furnace turns on and off frequently repair cost` | Informational / Commercial | MEDIUM | Overheating, high limit switch, flame sensor cleaning, oversized furnace issues. |
| **29** | `/hybrid-dual-fuel-heating-cost/` | `dual fuel heat pump system cost installed` | Commercial Investigation | HIGH | Heat pump + gas furnace pairing for sub-freezing northern climates. |
| **30** | `/hvac-by-state/virginia/` | `hvac replacement cost virginia` | Commercial Investigation | HIGH | Expansion to high-demand Mid-Atlantic state with mixed heating/cooling loads. |

---

## 3. Batch 3: Future Strategic Opportunities

1. **Geothermal Heat Pump Installation Cost (`/geothermal-heat-pump-cost/`):** Deep ground-loop vs. horizontal trenching ($20,000&ndash;$45,000); federal 30% Section 25D uncapped tax credits.
2. **Commercial Package Unit Guide (`/commercial-rooftop-hvac-cost/`):** 5 to 15-ton RTU replacement for small businesses and strip malls.
3. **Interactive Manual J Heat Gain Calculator:** Lightweight browser tool calculating envelope heat gain based on window orientation and wall R-values.
4. **Interactive Utility Rebate Lookup Directory:** State-by-state interactive table searchable by utility name (e.g., Oncor, Duke, ConEd, PG&E).
