# HVAC Cost Calculator &mdash; Methodology & Technical Specification

> **Document Version:** 2.0 (2026 Edition)  
> **Status:** Active Production Specification  
> **Target Audience:** Homeowners, Estimators, and Technical Auditors  
> **Primary Script Location:** [`/assets/js/calculator.js`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/assets/js/calculator.js) & [`/assets/js/hvac-data.js`](file:///C:/Users/الشبكة%20للحاسبات/.gemini/antigravity-ide/scratch/hvac-cost-guide/assets/js/hvac-data.js)

---

## 1. Overview & Core Philosophy

The **HVAC Cost Guide Calculator** is engineered to provide realistic, transparent, and defensible replacement and installation estimates for residential heating and cooling systems across the United States.

Unlike commercial lead-generation widgets that harvest user contact information before revealing arbitrary numbers, our calculator runs **entirely client-side in vanilla JavaScript**, requiring **zero personal data** and producing instant, granular cost ranges (Low, Average, High) with complete transparency into equipment vs. labor allocations.

---

## 2. Mathematical Estimation Model

The total estimated installed cost ($C_{total}$) is calculated through a multi-variable parametric model:

$$C_{total} = \left[ \left( B_{equipment} \times M_{eff} \right) + \left( B_{labor} \times L_{zip} \right) + \sum A_{addons} \right] \times \text{Variance Range}$$

### 2.1 Variables & Parameters

1. **Required System Capacity ($T$ in Tons):**
   $$T = \text{clamp}\left(\text{round}\left(\frac{\text{Square Footage}}{500} \times 2\right) / 2, \; 1.5, \; 5.0\right)$$
   *Explanation:* Residential sizing generally estimates 1 ton of cooling capacity per 400&ndash;600 square feet under standard 8-foot ceiling heights and average insulation. The calculator rounds to the nearest standard half-ton increment (1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0 tons).

2. **System Baseline Cost Constants ($B_{base}$ per Ton):**
   - **Central Air Conditioner:** $2,200 per ton (includes condenser, evaporator coil, line set flushing, pad, and disconnect).
   - **Gas Furnace:** $1,400 per ton / 40,000 BTU equivalent (includes 80%+ AFUE furnace, gas piping hookup, flue vent tie-in).
   - **Heat Pump (All-Electric Split):** $2,700 per ton (includes outdoor heat pump condenser, air handler, auxiliary electric heat strips).
   - **Full HVAC System (AC + Gas Furnace):** $3,400 per ton (combined heating and cooling changeout with shared air handler).
   - **Ductless Mini-Split:** $1,900 per zone (outdoor inverter condenser + indoor wall/ceiling air handler heads).

3. **Efficiency Multipliers ($M_{eff}$):**
   - **Standard Efficiency (14.3 SEER2 / 80% AFUE):** $1.00\times$ (Baseline federal minimum).
   - **High Efficiency (16&ndash;18 SEER2 / 92&ndash;96% AFUE):** $1.25\times$ (Two-stage compression, high-efficiency ECM blower).
   - **Ultra-High Efficiency (20+ SEER2 / 98% AFUE):** $1.55\times$ (Variable-capacity inverter modulating compressor).

4. **Regional Labor Adjustment Multiplier ($L_{zip}$):**
   Labor rates vary significantly across US metropolitan areas and rural regions. The calculator inspects the first 3 digits of the entered US ZIP code and matches against indexed Bureau of Labor Statistics (BLS) metropolitan wage tiers:
   - **High-Cost Metros (NYC, San Francisco, Boston, Seattle, Chicago):** $1.25\times &ndash; 1.35\times$
   - **Mid-to-High Metros (Denver, Los Angeles, DC, Philadelphia):** $1.15\times &ndash; 1.24\times$
   - **National Median Baseline (Dallas, Atlanta, Phoenix, Columbus, Charlotte):** $1.00\times$
   - **Low-Cost / Rural Areas (Midwest rural, deep South, Appalachia):** $0.88\times &ndash; 0.95\times$
   - **Fallback:** If an invalid or unlisted ZIP code is entered, the national baseline ($1.00\times$) is applied automatically with a visible indicator.

5. **Project Add-ons ($\sum A_{addons}$):**
   - **Full Ductwork Replacement:** $+\$2,000 &ndash; \$4,500$ (scaled to home square footage).
   - **Smart Thermostat Installation:** $+\$250 &ndash; \$450$ (hardware + 24V C-wire hookup).
   - **Electrical Service / Line Set Upgrade:** $+\$800 &ndash; \$1,500$ (required for older panels or larger amperage draws).

---

## 3. Cost Range Variance Formula

Contractor bids reflect local supply chain discounts, overhead, insurance, and warranty terms. To reflect real-world market variance, the calculator outputs three distinct tiers:

- **Low Range:** $0.85 \times C_{mid}$ (Economy brand, straightforward ground-level install, easy access).
- **Average (Most Common):** $1.00 \times C_{mid}$ (Mid-tier brand, standard changeout, licensed contractor warranty).
- **High Range:** $1.25 \times C_{mid}$ (Premium brand like Trane/Carrier, complex attic/closet access, extended 10-year labor warranty).

---

## 4. Cost Breakdown Allocation

Every calculation dynamically displays an itemized cost composition bar:

- **Equipment & Hardware:** $52\% &ndash; 58\%$ (condenser, furnace, coils, line sets, pads).
- **Skilled Labor & Installation:** $32\% &ndash; 38\%$ (EPA-certified refrigerant handling, electrical wiring, brazing, duct transitions).
- **Permits, Inspection & Disposal Fees:** $8\% &ndash; 10\%$ (municipal mechanical permit, old refrigerant recovery, recycling of scrapped metal).

---

## 5. Repair vs. Replace Decision Engine ($5,000 Rule)

When users input a non-zero system age along with a potential repair quote, the calculator triggers the **$5,000 Rule Engine**:

$$\text{Decision Index} = \text{System Age in Years} \times \text{Estimated Repair Cost}$$

### Decision Logic:
- **Decision Index $< \$3,000$ and Age $< 10$ Years:**  
  *Advisory:* **"Repair is Recommended."** The unit has remaining operational life, and repair investment is mathematically sound.
- **Decision Index between $\$3,000$ and $\$5,000$:**  
  *Advisory:* **"Borderline &mdash; Evaluate Efficiency & R-22 Status."** Consider whether existing equipment uses obsolete refrigerants or incurs high utility bills.
- **Decision Index $> \$5,000$ or Age $\ge 15$ Years:**  
  *Advisory:* **"Replacement is Financially Advisable."** Continuing to invest hundreds of dollars into a failing unit older than 12&ndash;15 years typically results in escalating breakdown cycles.

---

## 6. Input Validation & Error Handling

To ensure robust mobile and desktop UX:
- **Square Footage:** Validated between $500$ and $5,000$ sq ft. Numeric input boxes and range sliders stay synchronized bidirectionally.
- **System Age:** Clamped between $0$ and $25$ years.
- **ZIP Code:** Validated via regex `^\d{5}$`. Non-numeric characters are rejected gracefully without page refresh or script errors.

---

## 7. Limitations & Consumer Disclaimer

The calculator provides **informational estimates only**, not binding contractual quotes. Physical home variables that require an on-site technician include:
1. **Manual J Thermal Envelope:** Insulation R-values, window glass solar heat gain coefficient (SHGC), ceiling heights exceeding 9 feet, and home orientation.
2. **Ductwork Static Pressure (Manual D):** Undersized return air grilles or collapsed flex ducting that restricts airflow.
3. **Hazardous Materials:** Asbestos duct insulation wrap or lead paint requiring certified environmental remediation.
